import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

// This tells Astro: "every .md file in src/content/posts/ is a blog post,
// and it must have these fields at the top."
// If you typo a field name, the build fails loudly instead of publishing something broken.
const posts = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/posts' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    date: z.coerce.date(),
    tags: z.array(z.string()).default([]),
    draft: z.boolean().default(false),
  }),
});

export const collections = { posts };
