---
title: "Starting a notebook, and the one rule I'm giving myself"
description: "A place to put what I'm learning about code, math, and markets — written the day I learn it, while it's still slightly wrong."
date: 2026-09-19
tags: ["notes"]
draft: false
---

I've been keeping what I learn in three places: a Notion page I never reopen, the margins of a
textbook, and my own memory, which is the least reliable of the three. So: a notebook, in public.

## The rule

**Publish it while it's still slightly wrong.**

The instinct is to wait until I understand something properly before writing it down. But the gap
between "I followed the derivation" and "I could rebuild it from scratch" is exactly where the
learning happens, and it closes the moment I try to explain it. Waiting for certainty means
writing nothing.

So posts here are working notes, not conclusions. If I get something wrong, I'd rather find out
in public.

## What goes here

Three threads, which turn out to be one thread:

- **Code** — mostly Python, some Rust, whatever I broke this week
- **Math** — probability, linear algebra, and the stochastic calculus I'm working through now
- **Markets** — where the first two collide with something that doesn't care whether my model is elegant

## Proof that the math renders

The whole reason I built this instead of using a hosted blog: I want to write equations inline and
have them look right. Geometric Brownian motion, the model under Black–Scholes:

$$
dS_t = \mu S_t\,dt + \sigma S_t\,dW_t
$$

And inline, mid-sentence: the drift term $\mu S_t\,dt$ is the part you'd expect, and
$\sigma S_t\,dW_t$ is the part that makes it interesting. Good — that's LaTeX, typeset properly,
in a plain Markdown file.

Code blocks too:

```python
import numpy as np

def gbm(s0: float, mu: float, sigma: float, days: int, seed: int = 0) -> np.ndarray:
    """One geometric Brownian motion path, daily steps."""
    rng = np.random.default_rng(seed)
    dt = 1 / 252
    shocks = rng.standard_normal(days)
    # Note the -0.5 * sigma**2: the Itô correction, which I did not
    # understand for an embarrassingly long time.
    log_returns = (mu - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * shocks
    return s0 * np.exp(np.cumsum(log_returns))
```

That `-0.5 * sigma**2` is the first thing I want to write about properly. It's the entire reason
Itô calculus exists, and every time I've seen it explained the explanation assumed I already knew
why it was there.

Next post, then.
