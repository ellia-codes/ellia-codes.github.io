---
title: "Copy this file to start a new post"
description: "A one-sentence summary. This is what shows under the title on the homepage and in RSS, so make it say something."
date: 2026-09-19
tags: ["python", "math"]
draft: true
---

> This post has `draft: true` at the top, so it does **not** appear on the site.
> Copy the file, rename it, change `draft` to `false`, and write.

## How the front matter works

Everything between the two `---` lines at the top is the post's settings.

| Field | What it does |
| --- | --- |
| `title` | The heading, the browser tab, the homepage entry |
| `description` | One sentence, shown on the homepage and in RSS |
| `date` | Format `YYYY-MM-DD`. Sorts the homepage, newest first |
| `tags` | A list. Colors come from `src/site.config.ts` |
| `draft` | `true` hides it, `false` publishes it |

The **filename** becomes the web address: `ito-lemma.md` lives at `/posts/ito-lemma/`. Use
lowercase words with hyphens, no spaces, and don't rename it after publishing — that breaks any
link anyone saved.

## Things you can write

Regular paragraphs with **bold**, *italic*, [links](https://astro.build), and `inline code`.

Inline math with single dollar signs: the Sharpe ratio is $S = \frac{\mathbb{E}[R - R_f]}{\sigma}$,
which looks tidy and hides how unstable that denominator is over short windows.

Display math with double dollar signs on their own lines:

$$
\text{Var}\!\left(\sum_{i=1}^{n} w_i R_i\right) = \sum_{i=1}^{n}\sum_{j=1}^{n} w_i w_j \sigma_{ij}
$$

Code blocks, with the language after the backticks so it gets colored:

```python
returns = prices.pct_change().dropna()
sharpe = returns.mean() / returns.std() * (252 ** 0.5)
```

Bullet lists:

- first thing
- second thing

Numbered lists, when order actually matters:

1. do this
2. then this

Block quotes, for something worth setting apart:

> Past performance does not guarantee future results, and neither does a good backtest.

Images go in the `public/` folder and get linked like `![caption](/my-chart.png)`.

---

Delete everything above once you've got the hang of it.
