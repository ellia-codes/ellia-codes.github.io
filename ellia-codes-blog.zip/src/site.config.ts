// ─────────────────────────────────────────────────────────────
//  Everything about YOU lives in this one file.
//  Change it here and it updates across the whole site.
// ─────────────────────────────────────────────────────────────

export const site = {
  title: "Elia's Notebook",
  // The little mark in the top-left circle. One or two characters works best.
  glyph: 'λ',
  tagline: 'Working notes on code, math, and markets.',
  intro:
    "I write down what I'm figuring out — usually the day I figure it out, usually while it's still slightly wrong. Stochastic calculus, Python that runs fast enough, and honest backtests.",
  kicker: 'Learning in public · since 2026',
  author: 'Elia',
  url: 'https://ellia-codes.github.io',
};

export const nav = [
  { label: 'Writing', href: '/' },
  { label: 'About', href: '/about/' },
  { label: 'RSS', href: '/rss.xml' },
];

export const footerLinks = [
  { label: 'RSS', href: '/rss.xml' },
  { label: 'GitHub', href: 'https://github.com/ellia-codes' },
];

// The "What I'm learning now" box on the homepage.
// Colors available: 'mint', 'accent', 'honey', 'rose'
export const learningNow = [
  { color: 'mint', what: 'Stochastic calculus', detail: 'Shreve, vol. II, ch. 4' },
  { color: 'accent', what: 'Rust', detail: 'rewriting my data loader' },
  { color: 'honey', what: 'Market microstructure', detail: 'order book basics' },
];

// The "On the shelf" box. Delete the whole array to hide the box.
export const shelf = [
  { title: 'Stochastic Calculus for Finance II', by: 'Shreve' },
  { title: 'Advances in Financial Machine Learning', by: 'López de Prado' },
  { title: 'Trading and Exchanges', by: 'Harris' },
];

// Which pastel a tag gets. Anything not listed here falls back to the purple.
export const tagColors: Record<string, string> = {
  math: 'mint',
  'linear algebra': 'mint',
  probability: 'mint',
  statistics: 'mint',

  python: 'accent',
  polars: 'accent',
  rust: 'accent',
  code: 'accent',

  trading: 'honey',
  backtesting: 'honey',
  markets: 'honey',
  risk: 'honey',
  derivatives: 'honey',

  opinion: 'rose',
  notes: 'rose',
};
